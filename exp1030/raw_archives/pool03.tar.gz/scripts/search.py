#!/usr/bin/env python3
"""Remote resumable discovery -> 24-config HPO -> sealed confirmation."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS']:os.environ[k]='1'
import argparse,concurrent.futures as cf,hashlib,json,signal,subprocess,sys,time,traceback
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder,StandardScaler
HERE=Path(__file__).resolve().parent; BASE=HERE.parent
METHODS=['CrossGB','PL','LinXGBoost','PILOT','TAO']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix('.tmp');t.write_text(json.dumps(x,indent=2,allow_nan=False,default=str));t.replace(p)
def pools():
 rng=np.random.default_rng(26102914); out={m:[] for m in METHODS}
 def pick(v):return v[int(rng.integers(len(v)))]
 for i in range(24):
  # Six diverse anchors appear before randomized refinement; equal candidate counts.
  d=[1,2,3,4,5,3][i%6]; eta=[1.,.5,.2,.1,.05,.1][i%6]; nt=[2,8,32,100,300,150][i%6] if i<6 else pick([1,2,4,8,32,64,150,300,500])
  out['CrossGB'].append(dict(depth=d,trees=nt,ridge=[.001,.01,.1,1.,10.,100.][i%6],learning_rate=eta if i<6 else pick([.03,.1,.3,.5,1.]),p=1. if i<12 else pick([.5,.75,1.]),metagb_min_data_in_leaf=pick([2,5,10,20]),max_bin=127))
  out['PL'].append(dict(num_trees=nt,learning_rate=eta if i<6 else pick([.03,.1,.3,.5,1.]),num_leaves=2**d,max_var=[1,2,5][i%3],l2_reg=[.001,.01,.1,1.,10.,100.][i%6],l1_reg=0.,min_sum_hessians=pick([2,5,10,20]),num_bins=127,leaf_type='linear' if i%2==0 else 'half_additive'))
  out['LinXGBoost'].append(dict(n_estimators=[1,3,5,10,20,50][i%6] if i<6 else pick([1,2,5,10,20,50,100]),learning_rate=pick([.1,.3,.5,1.]),max_depth=d,lbda=[.001,.01,.1,1.,10.,100.][i%6],min_samples_leaf=pick([2,5,10,20])))
  out['PILOT'].append(dict(max_depth=[2,4,6,8,12,16][i%6],max_model_depth=pick([10,30,60,100]),min_sample_leaf=pick([3,5,10,20,40]),min_sample_split=pick([10,20,40,80]),rel_tolerance=pick([0.,.0001,.001,.01])))
  out['TAO'].append(dict(depth=[2,3,4,5,6,7][i%6],max_iter=pick([10,20,30]),C_dnode=float(10**rng.uniform(-2,2)),alpha=pick([0.,.5,1.])))
 return out

def cases():
 real=[dict(kind='simulation' if r['name']=='naval_propulsion_plant' else 'real',name=r['name'],raw=r) for r in json.loads((BASE/'raw/registry.json').read_text())]
 syn=[]
 # Parameter variants are scenarios, never counted as distinct mechanism families.
 for family in ['gate_sum','switch4','stair_slope','saturating','correlated_gate','hetero_gate']:
  for variant in range(8):
   syn.append(dict(kind='synthetic',name=f'{family}_v{variant}',family=family,variant=variant,d=[16,24,32,48][variant%4],n=[960,1920][variant//4],noise=[.15,.3][variant%2],modules=2+variant%3))
 base=[v for i in range(max(len(real),len(syn))) for v in ([real[i]] if i<len(real) else [])+([syn[i]] if i<len(syn) else [])]
 extra=BASE/'extra_registry_v2.json'
 return base+([dict(kind='real',name=r['name'],raw=r) for r in json.loads(extra.read_text())] if extra.exists() else [])

def data(case,stage,seed):
 out=BASE/'inputs'/case['name']/f'{stage}_{seed}.npz'
 if out.exists():return out
 rng=np.random.default_rng(seed);meta=dict(case=case,stage=stage,seed=seed)
 if case['kind'] in ['real','simulation']:
  raw=BASE/'raw'/case['raw']['file'];df=pd.read_csv(raw);y=pd.to_numeric(df.iloc[:,-1],errors='coerce');df=df.loc[y.notna()].copy(); y=y[y.notna()].to_numpy(float);X=df.iloc[:,:-1].drop(columns=case['raw']['drop'],errors='ignore')
  # Freeze a test partition once; it is never used in discovery or HPO.
  ix=np.random.default_rng(261029140).permutation(len(y));t=int(.2*len(ix));test=ix[:t];dev=ix[t:];dev=rng.permutation(dev)
  if stage=='screen':dev=dev[:min(1600,len(dev))]
  elif stage=='confirm':dev=dev[:max(2,int(.9*len(dev)))]
  cut=int(.75*len(dev));tr,va=dev[:cut],dev[cut:]
  nums=list(X.select_dtypes(include='number').columns);cats=[x for x in X if x not in nums]
  pre=ColumnTransformer([('num',make_pipeline(SimpleImputer(strategy='median',keep_empty_features=True),StandardScaler()),nums),('cat',make_pipeline(SimpleImputer(strategy='most_frequent'),OneHotEncoder(handle_unknown='ignore',sparse_output=False)),cats)],sparse_threshold=0)
  A=pre.fit_transform(X.iloc[tr]);B=pre.transform(X.iloc[va]);C=pre.transform(X.iloc[test]);X=np.vstack([A,B,C]);y=np.concatenate([y[tr],y[va],y[test]]);lens=[len(tr),len(va),len(test)];meta.update(source_sha256=sha(raw),original_indices=dict(train=tr.tolist(),val=va.tolist(),test=test.tolist()),preprocessing='train-only median/standardization + onehot; target train standardization')
 else:
  d,n=case['d'],case['n'];n=n if stage=='screen' else n*3;X=rng.normal(size=(n,d));m=case['modules'];f=case['family']
  if f in ['gate_sum','correlated_gate','hetero_gate']:
   if f=='correlated_gate':
    for j in range(2*m,d):X[:,j]=.8*X[:,2*m+(j-2*m)%2]+.6*rng.normal(size=n) if j>=2*m+2 else X[:,j]
   signal=sum(2/np.sqrt(m)*np.where(X[:,j]>0,1.,-1.)*X[:,m+j] for j in range(m))
  elif f=='switch4':
   region=2*(X[:,0]>0)+(X[:,1]>0);signal=2*np.array([-1,1,-1,1])[region]*X[np.arange(n),2+region]
  elif f=='stair_slope':signal=np.where(X[:,0]<-.5,-2.,np.where(X[:,0]<.5,.75,2.5))*X[:,1]+.15*X[:,2]
  else:signal=1.5*(np.clip(X[:,0],-1,1)*X[:,2]+np.clip(X[:,1],-1,1)*X[:,3])
  eps=rng.normal(size=n)*case['noise'];eps*=np.where(X[:,0]>0,2.,.5) if f=='hetero_gate' else 1.;y=signal+eps
  ix=rng.permutation(n);tr,va,test=np.split(ix,[int(.6*n),int(.8*n)]);X=np.vstack([X[tr],X[va],X[test]]);y=np.concatenate([y[tr],y[va],y[test]]);lens=[len(tr),len(va),len(test)];meta.update(formula=f,independent_draw=True,noise_sd=case['noise'],nuisance_features=d-2*m)
 a,b=np.cumsum(lens)[:2];indices=dict(train=np.arange(a),val=np.arange(a,b),test=np.arange(b,len(y)));ym=float(y[:a].mean());ys=float(y[:a].std()) or 1.;y=(y-ym)/ys
 out.parent.mkdir(parents=True,exist_ok=True);np.savez_compressed(out,X=np.asarray(X,np.float32),task_type=np.array('regression'),**indices,**{'y_'+k:y[v] for k,v in indices.items()});meta.update(y_mean=ym,y_scale=ys,rows=len(y),features=X.shape[1],npz_sha256=sha(out));write(out.with_suffix('.json'),meta);return out

def runfit(root,case,stage,seed,method,i,p,cores,timeout,final=False):
 out=BASE/'results'/case['name']/stage/str(seed)/method/str(i);r=out/'result.json'
 if r.exists():
  old=json.loads(r.read_text())
  if old.get('status') in ['ok','timeout','failed']:return old
 out.mkdir(parents=True,exist_ok=True);write(out/'params.json',p);dt=data(case,stage,seed)
 cmd=[sys.executable,str(HERE/'worker.py'),'--root',str(root),'--data',str(dt),'--method',method,'--seed',str(seed),'--params',str(out/'params.json'),'--output',str(out)]
 if final:cmd+=['--evaluate-test']
 start=time.monotonic()
 with (out/'process.log').open('w') as log:
  child=subprocess.Popen(['taskset','-c',str(cores[(i*5+METHODS.index(method))%len(cores)])]+cmd,stdout=log,stderr=log,start_new_session=True)
  try:code=child.wait(timeout=timeout)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
 result=json.loads(r.read_text()) if r.exists() else {}
 if code or result.get('status')!='ok':result.update(status='timeout' if code==124 else 'failed',exit_code=code);write(r,result)
 result['job_elapsed']=time.monotonic()-start;return result

def panel(a,case,stage,seed,count,selected=None):
 dt=data(case,stage,seed);jobs=[];scores={m:[] for m in METHODS};cost={m:0. for m in METHODS}
 for i in range(count):
  for m in METHODS:jobs.append((m,i,a.pool[m][i] if selected is None else selected[m]))
 with cf.ThreadPoolExecutor(max_workers=a.workers) as ex:
  tasks={ex.submit(runfit,a.root,case,stage,seed,m,i,p,a.cores,180 if stage=='screen' else 1200,selected is not None):(m,i,p) for m,i,p in jobs}
  for future in cf.as_completed(tasks):
   m,i,p=tasks[future];r=future.result();cost[m]+=r.get('job_elapsed',r.get('total_wall_sec',0.));scores[m].append(dict(index=i,params=p,status=r['status'],val=r.get('val_rmse'),test=r.get('test_rmse'),fit_cpu=r.get('timings',{}).get('fit_cpu_sec'),fit_wall=r.get('timings',{}).get('fit_wall_sec')))
   write(getattr(a,'progress_path',BASE/'progress.json'),dict(case=case['name'],stage=stage,seed=seed,done=sum(map(len,scores.values())),total=len(jobs),updated=time.time()))
 best={m:min([r for r in rows if r['status']=='ok'],key=lambda r:r['val'],default=None) for m,rows in scores.items()};report=dict(case=case,stage=stage,seed=seed,best=best,search_wall_sum=cost,candidates=scores);write(BASE/'summaries'/case['name']/f'{stage}_{seed}.json',report);return report

def promotion(best, margin):
 c=best.get('CrossGB')
 if c is None:return False
 vals=[v['val'] for v in best.values() if v is not None]
 rank=1+sum(v<c['val'] for v in vals)
 return rank<=3 or c['val']<=margin*min(vals)

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--shard',type=int,default=0);p.add_argument('--shards',type=int,default=6);p.add_argument('--workers',type=int,default=8);p.add_argument('--only');a=p.parse_args();a.progress_path=BASE/(f'progress_only_{a.only}.json' if a.only else 'progress.json');a.cores=sorted(os.sched_getaffinity(0));a.pool=pools();write(BASE/'candidate_pools_24.json',a.pool);allcases=cases();write(BASE/'case_registry.json',allcases)
 queue=[c for i,c in enumerate(allcases) if i%a.shards==a.shard and (not a.only or c['name']==a.only)]
 for c in queue:
  try:
   s=panel(a,c,'screen',261029141,6);best=s['best'];good=promotion(best,1.12);write(BASE/'decisions'/f"{c['name']}.json",dict(promote=good,screen_best=best))
   if not good:continue
   h=panel(a,c,'hpo',261029142,24);best=h['best'];good=all(best.values()) and promotion(best,1.03)
   if good:
    frozen=BASE/'frozen'/f"{c['name']}.json"
    if frozen.exists():selected=json.loads(frozen.read_text())['selected']
    else:
     selected={m:best[m]['params'] for m in METHODS};write(frozen,dict(selected=selected,hpo=best,frozen_before_test=time.time()))
    for seed in [261029151,261029152,261029153]:panel(a,c,'confirm',seed,1,selected)
   write(BASE/'decisions'/f"{c['name']}_hpo.json",dict(confirm=good,hpo_best=best))
  except Exception:write(BASE/'errors'/f"{c['name']}.json",dict(traceback=traceback.format_exc()))
 write(BASE/(f'only_{a.only}_complete.json' if a.only else 'shard_complete.json'),dict(shard=a.shard,cases=len(queue),time=time.time()))
if __name__=='__main__':main()

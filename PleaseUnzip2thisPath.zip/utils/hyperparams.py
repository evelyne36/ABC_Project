"""
Hyperparameter Configuration Module
Defines all hyperparameter search spaces and fixed configurations for experiments.
"""

# =============================================================================
# Global Configuration
# =============================================================================

RANDOM_SEED = 42
TRAIN_TEST_SPLIT = 0.8  # 80% train, 20% test
CV_FOLDS = 5  # K-fold cross-validation folds (Experiment 1 only)

# =============================================================================
# Experiment 1: Grid Search Parameter Spaces
# =============================================================================

# Common parameters shared by XGBoost and MetaGB
COMMON_PARAMS_GRID = {
    'learning_rate': [0.01, 0.05, 0.1],      # 3 values
    'max_depth': [3, 5, 10],                   # 3 values
    'n_estimators': [20, 50, 100],               # 2 values, reduced for faster grid search
    'subsample': [0.7, 1.0],                  # 2 values
}

# MetaGB-specific parameters
METAGB_SPECIFIC_PARAMS = {
    'pred_feature_fraction': [0.0, 0.4, 0.8],  # 3 values - key MetaGB parameter
    'version': [3],                             # Fixed: use version 3
    'max_bin': [64],                            # Fixed
    'min_data_in_leaf': [10],                   # Fixed
    'colsample_bytree': [0.7, 1.0],            # 2 values - feature_fraction in MetaGB
}

# XGBoost-specific parameters
XGBOOST_SPECIFIC_PARAMS = {
    'colsample_bytree': [0.7, 1.0],            # 2 values
    'max_bin': [64],                            # Fixed for histogram method
    'min_child_weight': [10],                   # Equivalent to min_data_in_leaf
    'reg_lambda': [0.0],                        # L2 regularization
}

# =============================================================================
# Experiment 2: Fixed Parameters (No Grid Search)
# =============================================================================

FIXED_COMMON_PARAMS = {
    'learning_rate': 0.05,
    'max_depth': 5,
    'n_estimators': 100,
    'subsample': 1.0,
    'colsample_bytree': 0.8,
}

FIXED_METAGB_PARAMS = {
    'version': 3,
    'max_bin': 64,
    'min_data_in_leaf': 20,
}

FIXED_XGBOOST_PARAMS = {
    'max_bin': 64,
    'min_child_weight': 20,
    'reg_lambda': 0.0,
}

# Experiment 2: pred_feature_fraction variants to test
PRED_FEATURE_FRACTIONS = [0.0, 0.4, 0.8]

# =============================================================================
# Noise Levels for Experiment 2A
# =============================================================================

NOISE_LEVELS = [0.0, 0.1, 0.3, 0.5, 0.6, 1.0, 10.0]

# =============================================================================
# Helper Functions
# =============================================================================

def get_xgb_param_grid():
    """
    Get the full XGBoost parameter grid for grid search.

    Returns:
        dict: Parameter grid for XGBoost
    """
    param_grid = {}
    param_grid.update(COMMON_PARAMS_GRID)
    param_grid.update(XGBOOST_SPECIFIC_PARAMS)
    return param_grid


def get_metagb_param_grid():
    """
    Get the full MetaGB parameter grid for grid search.

    Returns:
        dict: Parameter grid for MetaGB
    """
    param_grid = {}
    param_grid.update(COMMON_PARAMS_GRID)
    param_grid.update(METAGB_SPECIFIC_PARAMS)
    return param_grid


def get_fixed_xgb_params():
    """
    Get fixed XGBoost parameters for Experiment 2.

    Returns:
        dict: Fixed parameters for XGBoost
    """
    params = {}
    params.update(FIXED_COMMON_PARAMS)
    params.update(FIXED_XGBOOST_PARAMS)
    return params


def get_fixed_metagb_params(pred_feature_fraction=0.0):
    """
    Get fixed MetaGB parameters for Experiment 2.

    Args:
        pred_feature_fraction: The pred_feature_fraction value to use

    Returns:
        dict: Fixed parameters for MetaGB
    """
    params = {}
    params.update(FIXED_COMMON_PARAMS)
    params.update(FIXED_METAGB_PARAMS)
    params['pred_feature_fraction'] = pred_feature_fraction
    return params


def get_model_variants_exp2():
    """
    Get all model variants for Experiment 2.

    Returns:
        list: List of (model_name, model_type, params) tuples
    """
    variants = []

    # XGBoost
    variants.append(('XGBoost', 'xgboost', get_fixed_xgb_params()))

    # MetaGB variants with different pred_feature_fraction
    for pff in PRED_FEATURE_FRACTIONS:
        name = f'MetaGB_v{pff}'
        variants.append((name, 'metagb_v3', get_fixed_metagb_params(pff)))

    return variants


def print_param_grid_info():
    """Print information about parameter grid sizes."""
    xgb_grid = get_xgb_param_grid()
    metagb_grid = get_metagb_param_grid()

    xgb_combinations = 1
    for values in xgb_grid.values():
        xgb_combinations *= len(values)

    metagb_combinations = 1
    for values in metagb_grid.values():
        metagb_combinations *= len(values)

    print("=" * 60)
    print("Parameter Grid Information")
    print("=" * 60)
    print(f"\nXGBoost Grid Search:")
    for k, v in xgb_grid.items():
        print(f"  {k}: {v}")
    print(f"  Total combinations: {xgb_combinations}")

    print(f"\nMetaGB Grid Search:")
    for k, v in metagb_grid.items():
        print(f"  {k}: {v}")
    print(f"  Total combinations: {metagb_combinations}")
    print("=" * 60)


if __name__ == "__main__":
    print_param_grid_info()

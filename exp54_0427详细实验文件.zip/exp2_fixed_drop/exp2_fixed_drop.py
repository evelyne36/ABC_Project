"""
exp2_fixed_drop.py - Secondary Analysis Experiment (drop encoding)

Three branches per dataset × outer fold:
  A: XGB-fix       - xgb_best_k params, run once as benchmark
  B: MGB-best-base - mgb_best_k base params, sweep 11 pred values via inner 4-fold CV
  C: XGB-best-base - xgb_best_k mapped to MetaGB, sweep 11 pred values via inner 4-fold CV

Output: exp2_fixed_drop/ (root dir)
"""

import sys
import os
import json
import time
import warnings
import traceback
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from concurrent.futures import ProcessPoolExecutor, as_completed
from joblib import Parallel, delayed

warnings.filterwarnings('ignore')

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
EXP2_DIR = os.path.join(ROOT_DIR, 'exp2_drop')
DATA_DIR = os.path.join(ROOT_DIR, 'dataset', 'tabArena_regression')
OUT_DIR  = os.path.join(ROOT_DIR, 'exp2_fixed_drop')

sys.path.insert(0, EXP2_DIR)
sys.path.insert(0, os.path.join(EXP2_DIR, 'utils'))
sys.path.insert(0, os.path.join(EXP2_DIR, 'metagb'))

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
RANDOM_SEED = 42
OUTER_K     = 5
INNER_K     = 4
PRED_VALUES = [round(i * 0.1, 1) for i in range(11)]
TOP_K_PRED  = 3

DATASETS = [
    "airfoil_self_noise.csv",
    "Another-Dataset-on-used-Fiat-500.csv",
    "concrete_compressive_strength.csv",
    "diamonds.csv",
    "Food_Delivery_Time.csv",
    "healthcare_insurance_expenses.csv",
    "houses.csv",
    "miami_housing.csv",
    "physiochemical_protein.csv",
    "QSAR_fish_toxicity.csv",
    "wine_quality.csv",
]

def _env_int(name, default):
    raw = os.getenv(name)
    if raw is None or str(raw).strip() == "":
        return int(default)
    try:
        return max(1, int(raw))
    except (TypeError, ValueError):
        return int(default)

N_JOBS           = _env_int("METAGB_PARAM_JOBS", 1)
XGB_INNER_N_JOBS = _env_int("METAGB_XGB_INNER_JOBS", 1)
TOTAL_WORKERS    = _env_int("METAGB_TOTAL_WORKERS", 16)

# ---------------------------------------------------------------------------
# Data loading (drop categorical)
# ---------------------------------------------------------------------------
def load_data(csv_path):
    df = pd.read_csv(csv_path).select_dtypes(include=[np.number]).dropna()
    if len(df) == 0:
        raise ValueError(f"No valid data in {csv_path}")
    return df.iloc[:, :-1].values, df.iloc[:, -1].values

# ---------------------------------------------------------------------------
# Best params loading  (fold1~fold5 naming)
# ---------------------------------------------------------------------------
def load_best_params(dataset_name, model, outer_fold):
    fname = f"exp1_bestparams_{model}_fold{outer_fold}.json"
    path  = os.path.join(EXP2_DIR, 'logs', 'exp1_bestparams', dataset_name, fname)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Best params not found: {path}")
    with open(path) as f:
        data = json.load(f)
    return data['best_params']

# ---------------------------------------------------------------------------
# Parameter mapping
# ---------------------------------------------------------------------------
def map_xgb_to_metagb(xgb_params):
    mapping  = {'n_estimators': 'num_trees',
                'colsample_bytree': 'feature_fraction',
                'subsample': 'bagging_fraction'}
    drop_keys = {'reg_lambda', 'enable_categorical',
                 'tree_method', 'device', 'n_jobs'}
    result = {}
    for k, v in xgb_params.items():
        if k in drop_keys:
            continue
        if k == 'min_child_weight':
            result['min_data_in_leaf'] = max(1, int(round(v)))
        elif k in mapping:
            result[mapping[k]] = v
        else:
            result[k] = v
    result.setdefault('version', 3)
    result.setdefault('min_data_in_leaf', 10)
    result.setdefault('max_bin', 255)
    result.setdefault('bagging_fraction', 0.8)
    result.setdefault('feature_fraction', 0.8)
    return result

# ---------------------------------------------------------------------------
# Model training
# ---------------------------------------------------------------------------
def train_xgb(params, X_train, y_train):
    import xgboost as xgb
    p = {k: v for k, v in params.items()
         if k not in ('tree_method', 'device', 'n_jobs')}
    p.update({'tree_method': 'hist', 'device': 'cpu', 'n_jobs': XGB_INNER_N_JOBS})
    model = xgb.XGBRegressor(**p, random_state=RANDOM_SEED)
    model.fit(X_train, y_train, verbose=False)
    return model

def train_metagb(params, X_train, y_train):
    from metagb.metagb_utils import MetaGB
    p = params.copy()
    p['seed'] = RANDOM_SEED
    model = MetaGB(**p)
    model.fit(X_train, y_train)
    return model

def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))

def metrics(y_true, y_pred):
    r    = rmse(y_true, y_pred)
    mae  = float(np.mean(np.abs(y_true - y_pred)))
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    r2   = float(1 - ss_res / ss_tot) if ss_tot > 0 else 0.0
    return {'rmse': r, 'mae': mae, 'r2': r2}

# ---------------------------------------------------------------------------
# Branch A
# ---------------------------------------------------------------------------
def run_branch_a(xgb_params, X_train, y_train, X_test, y_test):
    model = train_xgb(xgb_params, X_train, y_train)
    return metrics(y_test, model.predict(X_test))

# ---------------------------------------------------------------------------
# Inner CV for one pred value
# ---------------------------------------------------------------------------
def _eval_pred_inner(pred_val, base_params, X_train_outer, y_train_outer):
    params = base_params.copy()
    params['pred_feature_fraction'] = pred_val
    inner_kf = KFold(n_splits=INNER_K, shuffle=True, random_state=RANDOM_SEED)
    fold_rmses = []
    for tr_idx, val_idx in inner_kf.split(X_train_outer):
        model = train_metagb(params, X_train_outer[tr_idx], y_train_outer[tr_idx])
        fold_rmses.append(rmse(y_train_outer[val_idx], model.predict(X_train_outer[val_idx])))
    return {'pred': pred_val, 'cv_rmse': float(np.mean(fold_rmses))}

# ---------------------------------------------------------------------------
# Branches B & C
# ---------------------------------------------------------------------------
def run_branch_bc(base_params, X_train, y_train, X_test, y_test):
    cv_results = []
    for pv in PRED_VALUES:
        r = _eval_pred_inner(pv, base_params, X_train, y_train)
        cv_results.append(r)
        print(f"  pred={r['pred']:.1f} cv_rmse={r['cv_rmse']:.6f}", flush=True)
    cv_results.sort(key=lambda x: x['cv_rmse'])
    top3 = cv_results[:TOP_K_PRED]
    print(f"  top3: " + ", ".join(f"pred={e['pred']:.1f}(cv={e['cv_rmse']:.4f})" for e in top3), flush=True)

    test_results = []
    for entry in top3:
        params = base_params.copy()
        params['pred_feature_fraction'] = entry['pred']
        model = train_metagb(params, X_train, y_train)
        m = metrics(y_test, model.predict(X_test))
        test_results.append({'pred': entry['pred'], 'cv_rmse': entry['cv_rmse'], **m})

    return {
        'all_cv': cv_results,
        'top3': test_results,
        'best_pred': test_results[0]['pred'],
        'best_cv_rmse': test_results[0]['cv_rmse'],
        'best_test_rmse': test_results[0]['rmse'],
    }

# ---------------------------------------------------------------------------
# One task
# ---------------------------------------------------------------------------
def run_task(task):
    dataset_name = task['dataset_name']
    outer_fold   = task['outer_fold']
    branch       = task['branch']

    logs_dir = os.path.join(OUT_DIR, 'logs', dataset_name)
    os.makedirs(logs_dir, exist_ok=True)

    fold_suffix = f"_fold{outer_fold}"
    branch_tag  = {'A': 'xgb', 'B': 'mgb_base', 'C': 'xgb_base'}[branch]
    out_json    = os.path.join(logs_dir, f"fixed_{branch_tag}{fold_suffix}.json")

    if os.path.exists(out_json):
        with open(out_json) as f:
            return {'dataset_name': dataset_name, 'outer_fold': outer_fold,
                    'branch': branch, 'result': json.load(f), 'error': None}

    print(f"[START] {dataset_name} fold{outer_fold} branch={branch}", flush=True)
    try:
        X, y = load_data(task['csv_path'])
        outer_kf = KFold(n_splits=OUTER_K, shuffle=True, random_state=RANDOM_SEED)
        splits = list(outer_kf.split(X))
        tr_idx, te_idx = splits[outer_fold - 1]
        X_train, X_test = X[tr_idx], X[te_idx]
        y_train, y_test = y[tr_idx], y[te_idx]

        xgb_params = load_best_params(dataset_name, 'xgboost', outer_fold)

        if branch == 'A':
            result = run_branch_a(xgb_params, X_train, y_train, X_test, y_test)
            out = {'dataset': dataset_name, 'outer_fold': outer_fold,
                   'branch': 'A_xgb_fix', 'xgb_params': xgb_params, **result}

        elif branch == 'B':
            mgb_params = load_best_params(dataset_name, 'metagb', outer_fold)
            base = {k: v for k, v in mgb_params.items() if k != 'pred_feature_fraction'}
            # normalize to MetaGB naming
            for old, new in [('n_estimators','num_trees'),('colsample_bytree','feature_fraction'),
                              ('colsample','feature_fraction'),('subsample','bagging_fraction')]:
                if old in base:
                    base[new] = base.pop(old)
            if 'min_child_weight' in base:
                base['min_data_in_leaf'] = max(1, int(round(base.pop('min_child_weight'))))
            base.setdefault('version', 3)
            base.setdefault('min_data_in_leaf', 10)
            base.setdefault('max_bin', 255)
            base.setdefault('bagging_fraction', 0.8)
            base.setdefault('feature_fraction', 0.8)
            result = run_branch_bc(base, X_train, y_train, X_test, y_test)
            out = {'dataset': dataset_name, 'outer_fold': outer_fold,
                   'branch': 'B_mgb_best_base', 'base_params': base, **result}

        else:  # C
            base = map_xgb_to_metagb(xgb_params)
            result = run_branch_bc(base, X_train, y_train, X_test, y_test)
            out = {'dataset': dataset_name, 'outer_fold': outer_fold,
                   'branch': 'C_xgb_best_base', 'base_params': base, **result}

        with open(out_json, 'w') as f:
            json.dump(out, f, indent=2)

        if branch == 'A':
            print(f"[DONE] {dataset_name} fold{outer_fold} branch={branch} test_rmse={out.get('rmse', 'N/A'):.6f}", flush=True)
        else:
            print(f"[DONE] {dataset_name} fold{outer_fold} branch={branch} best_pred={out['best_pred']} cv_rmse={out['best_cv_rmse']:.6f} test_rmse={out['best_test_rmse']:.6f}", flush=True)

        return {'dataset_name': dataset_name, 'outer_fold': outer_fold,
                'branch': branch, 'result': out, 'error': None}

    except Exception:
        return {'dataset_name': dataset_name, 'outer_fold': outer_fold,
                'branch': branch, 'result': None, 'error': traceback.format_exc()}

# ---------------------------------------------------------------------------
# Aggregate
# ---------------------------------------------------------------------------
def aggregate_results(results_dir, logs_dir):
    rows = []
    for ds_dir in os.listdir(logs_dir):
        ds_path = os.path.join(logs_dir, ds_dir)
        if not os.path.isdir(ds_path):
            continue
        for fname in os.listdir(ds_path):
            if not fname.endswith('.json'):
                continue
            with open(os.path.join(ds_path, fname)) as f:
                d = json.load(f)
            branch = d.get('branch', '')
            fold   = d.get('outer_fold')
            ds     = d.get('dataset')
            if 'A' in branch:
                rows.append({'dataset': ds, 'outer_fold': fold, 'branch': branch,
                             'rank': 1, 'best_pred': 0.0, 'cv_rmse': None,
                             'test_rmse': d.get('rmse'), 'test_r2': d.get('r2')})
            else:
                for i, t in enumerate(d.get('top3', [])):
                    rows.append({'dataset': ds, 'outer_fold': fold, 'branch': branch,
                                 'rank': i+1, 'best_pred': t['pred'],
                                 'cv_rmse': t['cv_rmse'],
                                 'test_rmse': t['rmse'], 'test_r2': t['r2']})
    if not rows:
        return
    df = pd.DataFrame(rows).sort_values(['dataset', 'outer_fold', 'branch'])
    df.to_csv(os.path.join(results_dir, 'fixed_summary.csv'), index=False)

    rank1 = df[df['rank'] == 1]
    agg = rank1.groupby(['dataset', 'branch'])['test_rmse'].agg(['mean', 'std']).reset_index()
    agg.columns = ['dataset', 'branch', 'test_rmse_mean', 'test_rmse_std']
    agg.to_csv(os.path.join(results_dir, 'fixed_aggregate.csv'), index=False)

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    logs_dir    = os.path.join(OUT_DIR, 'logs')
    results_dir = os.path.join(OUT_DIR, 'results')
    os.makedirs(logs_dir, exist_ok=True)
    os.makedirs(results_dir, exist_ok=True)

    tasks = []
    for ds in DATASETS:
        name = os.path.splitext(ds)[0]
        path = os.path.join(DATA_DIR, ds)
        if not os.path.exists(path):
            print(f"[WARN] Dataset not found: {path}")
            continue
        for fold in range(1, OUTER_K + 1):
            for branch in ('A', 'B', 'C'):
                tasks.append({
                    'dataset_name': name,
                    'csv_path': path,
                    'outer_fold': fold,
                    'branch': branch,
                    'cost': os.path.getsize(path) * (1 if branch == 'A' else 3),
                })

    tasks.sort(key=lambda t: t['cost'], reverse=True)
    max_workers = min(TOTAL_WORKERS, len(tasks))
    print(f"Total tasks: {len(tasks)}, workers: {max_workers}")

    completed = 0
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        future_map = {executor.submit(run_task, t): t for t in tasks}
        for future in as_completed(future_map):
            completed += 1
            r = future.result()
            if r['error']:
                print(f"[{completed}/{len(tasks)}] ERROR {r['dataset_name']} fold{r['outer_fold']} {r['branch']}")
                print(r['error'][:300])
            else:
                print(f"[{completed}/{len(tasks)}] OK {r['dataset_name']} fold{r['outer_fold']} branch={r['branch']}")
            if completed % 10 == 0 or completed == len(tasks):
                aggregate_results(results_dir, logs_dir)

    aggregate_results(results_dir, logs_dir)
    print(f"\nDone. Results in: {results_dir}")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--workers', type=int, default=None)
    parser.add_argument('--param_jobs', type=int, default=None)
    args = parser.parse_args()
    if args.workers:
        TOTAL_WORKERS = args.workers
    if args.param_jobs:
        N_JOBS = args.param_jobs
    main()

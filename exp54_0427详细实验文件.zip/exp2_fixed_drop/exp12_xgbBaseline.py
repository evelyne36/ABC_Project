"""
exp12_xgbBaseline.py - XGBoost Baseline (drop encoding, Branch A only)

Re-runs XGBoost with best params from exp2_drop on the same fixed-seed 5-fold CV.
Adds inner 4-fold CV_RMSE that was missing from the original exp2 Branch A output.

Output: exp12_xgbBaseline/logs/<dataset>/xgb_baseline_fold{fold}.json
        exp12_xgbBaseline/results/summary.csv
        exp12_xgbBaseline/results/aggregate.csv
"""

import sys
import os
import json
import warnings
import traceback
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from concurrent.futures import ProcessPoolExecutor, as_completed

warnings.filterwarnings('ignore')

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
EXP2_DIR = os.path.join(ROOT_DIR, 'exp2_drop')
DATA_DIR = os.path.join(ROOT_DIR, 'dataset', 'tabArena_regression')
OUT_DIR  = os.path.join(ROOT_DIR, 'exp12_xgbBaseline')

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
RANDOM_SEED = 42
OUTER_K     = 5
INNER_K     = 4

DATASETS = [
    "airfoil_self_noise.csv",
    "Another-Dataset-on-used-Fiat-500.csv",
    "concrete_compressive_strength.csv",
    "diamonds.csv",
    "Food_Delivery_Time.csv",
    "healthcare_insurance_expenses.csv",
    "houses.csv",
    "miami_housing.csv",
    "physiochemical_protein.csv",
    "QSAR_fish_toxicity.csv",
    "wine_quality.csv",
]

def _env_int(name, default):
    raw = os.getenv(name)
    if raw is None or str(raw).strip() == "":
        return int(default)
    try:
        return max(1, int(raw))
    except (TypeError, ValueError):
        return int(default)

XGB_INNER_N_JOBS = _env_int("METAGB_XGB_INNER_JOBS", 1)
TOTAL_WORKERS    = _env_int("METAGB_TOTAL_WORKERS", 16)

# ---------------------------------------------------------------------------
# Data loading (drop categorical, same as exp2)
# ---------------------------------------------------------------------------
def load_data(csv_path):
    df = pd.read_csv(csv_path).select_dtypes(include=[np.number]).dropna()
    if len(df) == 0:
        raise ValueError(f"No valid data in {csv_path}")
    return df.iloc[:, :-1].values, df.iloc[:, -1].values

# ---------------------------------------------------------------------------
# Best params loading (exp2_drop naming: _fold{fold})
# ---------------------------------------------------------------------------
def load_best_params(dataset_name, outer_fold):
    fname = f"exp1_bestparams_xgboost_fold{outer_fold}.json"
    path  = os.path.join(EXP2_DIR, 'logs', 'exp1_bestparams', dataset_name, fname)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Best params not found: {path}")
    with open(path) as f:
        data = json.load(f)
    return data['best_params']

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def train_xgb(params, X_train, y_train):
    import xgboost as xgb
    p = {k: v for k, v in params.items()
         if k not in ('tree_method', 'device', 'n_jobs')}
    p.update({'tree_method': 'hist', 'device': 'cpu', 'n_jobs': XGB_INNER_N_JOBS})
    model = xgb.XGBRegressor(**p, random_state=RANDOM_SEED)
    model.fit(X_train, y_train, verbose=False)
    return model

def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))

def metrics(y_true, y_pred):
    r      = rmse(y_true, y_pred)
    mae    = float(np.mean(np.abs(y_true - y_pred)))
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    r2     = float(1 - ss_res / ss_tot) if ss_tot > 0 else 0.0
    return {'rmse': r, 'mae': mae, 'r2': r2}

# ---------------------------------------------------------------------------
# One task: dataset × outer_fold
# ---------------------------------------------------------------------------
def run_task(task):
    dataset_name = task['dataset_name']
    outer_fold   = task['outer_fold']

    logs_dir = os.path.join(OUT_DIR, 'logs', dataset_name)
    os.makedirs(logs_dir, exist_ok=True)
    out_json = os.path.join(logs_dir, f"xgb_baseline_fold{outer_fold}.json")

    if os.path.exists(out_json):
        with open(out_json) as f:
            return {'dataset_name': dataset_name, 'outer_fold': outer_fold,
                    'result': json.load(f), 'error': None}

    print(f"[START] {dataset_name} fold{outer_fold}", flush=True)
    try:
        X, y = load_data(task['csv_path'])
        outer_kf = KFold(n_splits=OUTER_K, shuffle=True, random_state=RANDOM_SEED)
        splits   = list(outer_kf.split(X))
        tr_idx, te_idx = splits[outer_fold - 1]
        X_train, X_test = X[tr_idx], X[te_idx]
        y_train, y_test = y[tr_idx], y[te_idx]

        xgb_params = load_best_params(dataset_name, outer_fold)

        # Inner CV for CV_RMSE
        inner_kf   = KFold(n_splits=INNER_K, shuffle=True, random_state=RANDOM_SEED)
        cv_rmses   = []
        for itr, ival in inner_kf.split(X_train):
            m = train_xgb(xgb_params, X_train[itr], y_train[itr])
            cv_rmses.append(rmse(y_train[ival], m.predict(X_train[ival])))
        cv_rmse_mean = float(np.mean(cv_rmses))
        cv_rmse_std  = float(np.std(cv_rmses))

        # Final model on full outer train, eval on outer test
        model      = train_xgb(xgb_params, X_train, y_train)
        test_m     = metrics(y_test, model.predict(X_test))

        out = {
            'dataset':       dataset_name,
            'outer_fold':    outer_fold,
            'xgb_params':    xgb_params,
            'cv_rmse':       cv_rmse_mean,
            'cv_rmse_std':   cv_rmse_std,
            **test_m,          # test_rmse -> 'rmse', also 'mae', 'r2'
        }

        with open(out_json, 'w') as f:
            json.dump(out, f, indent=2)

        print(f"[DONE] {dataset_name} fold{outer_fold} "
              f"cv_rmse={cv_rmse_mean:.6f} test_rmse={test_m['rmse']:.6f}", flush=True)
        return {'dataset_name': dataset_name, 'outer_fold': outer_fold,
                'result': out, 'error': None}

    except Exception:
        return {'dataset_name': dataset_name, 'outer_fold': outer_fold,
                'result': None, 'error': traceback.format_exc()}

# ---------------------------------------------------------------------------
# Aggregate
# ---------------------------------------------------------------------------
def aggregate_results(results_dir, logs_dir):
    rows = []
    for ds_dir in os.listdir(logs_dir):
        ds_path = os.path.join(logs_dir, ds_dir)
        if not os.path.isdir(ds_path):
            continue
        for fname in os.listdir(ds_path):
            if not fname.endswith('.json'):
                continue
            with open(os.path.join(ds_path, fname)) as f:
                d = json.load(f)
            rows.append({
                'dataset':    d.get('dataset'),
                'outer_fold': d.get('outer_fold'),
                'cv_rmse':    d.get('cv_rmse'),
                'cv_rmse_std':d.get('cv_rmse_std'),
                'test_rmse':  d.get('rmse'),
                'test_mae':   d.get('mae'),
                'test_r2':    d.get('r2'),
            })
    if not rows:
        return
    df = pd.DataFrame(rows).sort_values(['dataset', 'outer_fold'])
    df.to_csv(os.path.join(results_dir, 'summary.csv'), index=False)

    agg = df.groupby('dataset')[['cv_rmse', 'test_rmse', 'test_r2']].agg(['mean', 'std']).reset_index()
    agg.columns = ['dataset'] + [f"{c}_{s}" for c, s in agg.columns[1:]]
    agg.to_csv(os.path.join(results_dir, 'aggregate.csv'), index=False)

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    logs_dir    = os.path.join(OUT_DIR, 'logs')
    results_dir = os.path.join(OUT_DIR, 'results')
    os.makedirs(logs_dir, exist_ok=True)
    os.makedirs(results_dir, exist_ok=True)

    tasks = []
    for ds in DATASETS:
        name = os.path.splitext(ds)[0]
        path = os.path.join(DATA_DIR, ds)
        if not os.path.exists(path):
            print(f"[WARN] Dataset not found: {path}")
            continue
        for fold in range(1, OUTER_K + 1):
            tasks.append({'dataset_name': name, 'csv_path': path, 'outer_fold': fold,
                          'cost': os.path.getsize(path)})

    tasks.sort(key=lambda t: t['cost'], reverse=True)
    max_workers = min(TOTAL_WORKERS, len(tasks))
    print(f"Total tasks: {len(tasks)}, workers: {max_workers}")

    completed = 0
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        future_map = {executor.submit(run_task, t): t for t in tasks}
        for future in as_completed(future_map):
            completed += 1
            r = future.result()
            if r['error']:
                print(f"[{completed}/{len(tasks)}] ERROR {r['dataset_name']} fold{r['outer_fold']}")
                print(r['error'][:300])
            else:
                print(f"[{completed}/{len(tasks)}] OK {r['dataset_name']} fold{r['outer_fold']}")
            if completed % 10 == 0 or completed == len(tasks):
                aggregate_results(results_dir, logs_dir)

    aggregate_results(results_dir, logs_dir)
    print(f"\nDone. Results in: {results_dir}")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--workers', type=int, default=None)
    args = parser.parse_args()
    if args.workers:
        TOTAL_WORKERS = args.workers
    main()

"""
Experiment: Study the impact of pred_feature_fraction on MetaGB performance

For each hyperparameter combination (fixed except n_estimators):
- Train 1 XGBoost model
- Train 11 MetaGB models with pred_feature_fraction from 0.0 to 1.0 (step 0.1)
- Only optimize n_estimators (simulating early stopping)

All hyperparameters are configured in this file independently.
"""

import sys
import os
import warnings
import numpy as np
import pandas as pd
import time
import json
import logging
import traceback
from datetime import datetime
from sklearn.model_selection import KFold
from itertools import product
from concurrent.futures import ProcessPoolExecutor, as_completed

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'utils'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'metagb'))

from utils.trainer import calculate_metrics
from utils.logger import ExperimentLogger
from joblib import Parallel, delayed

warnings.filterwarnings('ignore')

# =============================================================================
# Configuration (All hyperparameters defined here)
# =============================================================================

RANDOM_SEED = 42
N_JOBS = 1
XGB_INNER_N_JOBS = 1
TOTAL_DATASET_WORKERS = 16


def build_outer_fold_suffix(outer_fold_num):
    """Build filename suffix for outer fold tracking."""
    return f"_out{outer_fold_num}"


def _build_dataset_task_logger(exp_tag, dataset_name, logs_dir):
    """Create an isolated logger for one dataset worker process."""
    worker_log_dir = os.path.join(logs_dir, "dataset_workers", dataset_name)
    os.makedirs(worker_log_dir, exist_ok=True)
    return ExperimentLogger(
        f"{exp_tag}_{dataset_name}_{os.getpid()}",
        log_dir=worker_log_dir,
        console_level=logging.WARNING,
    )


def _run_pred_fraction_task(task):
    """Run one dataset pred-fraction task in a separate process."""
    global N_JOBS, XGB_INNER_N_JOBS
    N_JOBS = 1
    XGB_INNER_N_JOBS = 1

    dataset_logger = _build_dataset_task_logger(task['exp_tag'], task['dataset_name'], task['logs_dir'])
    try:
        df = run_pred_fraction_study(
            task['dataset_name'],
            task['dataset_path'],
            dataset_logger,
            task['results_dir'],
            outer_k=task['outer_k'],
            inner_k=task['inner_k'],
        )
        save_outer_cv_aggregate(df, task['dataset_name'], task['results_dir'], task['outer_k'])
        return {'dataset_name': task['dataset_name'], 'rows': len(df), 'error': None}
    except Exception:
        return {'dataset_name': task['dataset_name'], 'rows': 0, 'error': traceback.format_exc()}
    finally:
        dataset_logger.close()


# Datasets to test
EXP1_DATASETS = [
    "airfoil_self_noise.csv",
    "Another-Dataset-on-used-Fiat-500.csv",
    "concrete_compressive_strength.csv",
    "diamonds.csv",
    "Food_Delivery_Time.csv",
    "healthcare_insurance_expenses.csv",
    "houses.csv",
    "miami_housing.csv",
    "physiochemical_protein.csv",
    "QSAR_fish_toxicity.csv",
    "wine_quality.csv"
]

# Categorical handling: 'drop' or 'onehot'
CATEGORICAL_HANDLING = 'drop'

# Pred feature fraction values to test (0.0 to 1.0, step 0.1)
PRED_FRACTIONS = [round(x * 0.1, 1) for x in range(11)]

# Fixed hyperparameter grid (excluding n_estimators)
# These parameters are shared between XGBoost and MetaGB

#总组合=2*3*2*2*（1个XGBoost+11个MetaGB）=288个实验
FIXED_PARAM_GRID = {
    'learning_rate': [0.01, 0.1],
    'max_depth': [4, 6, 8],
    'subsample': [0.8, 1.0],
    'colsample_bytree': [0.8, 1.0],
}


# n_estimators search space (only this parameter is optimized)
# 模拟早停，范围较大，仅用于寻找最佳n_estimators，最终结果只保留最佳n_estimators对应的模型性能
N_ESTIMATORS_GRID = [ 200, 400, 600, 800]

# # smallTest_OK
# FIXED_PARAM_GRID = {
#     'learning_rate': [ 0.1],
#     'max_depth': [4],
#     'subsample': [0.8 ],
#     'colsample_bytree': [0.8],
# }
# # n_estimators search space (only this parameter is optimized)
# N_ESTIMATORS_GRID = [50]

# XGBoost-specific fixed parameters (with defaults exposed)
XGBOOST_FIXED_PARAMS = {
    'max_bin': 255,
    'min_child_weight': 10,
    'reg_lambda': 1.0,
    'reg_alpha': 0.0,
    'gamma': 0.0,
    'colsample_bylevel': 1.0,#default 1.0, not commonly tuned
    'colsample_bynode': 1.0,#default 1.0, not commonly tuned
    'tree_method': 'hist',
    'device': 'cpu',
}

# MetaGB-specific fixed parameters (with defaults exposed)
METAGB_FIXED_PARAMS = {
    'max_bin': 255,
    'min_data_in_leaf': 10,
    'version': 3,
}


def load_dataset(csv_path):
    """Load dataset with categorical handling but NO normalization."""
    df = pd.read_csv(csv_path)

    if CATEGORICAL_HANDLING == 'drop':
        df = df.select_dtypes(include=[np.number]).dropna()
    elif CATEGORICAL_HANDLING == 'onehot':
        categorical_cols = df.select_dtypes(exclude=[np.number]).columns
        if len(categorical_cols) > 0:
            df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)
        df = df.dropna()

    if len(df) == 0:
        raise ValueError(f"No valid data in {csv_path}")

    X = df.iloc[:, :-1].values
    y = df.iloc[:, -1].values

    return X, y


def train_and_evaluate_xgboost(params, X_train_outer, y_train_outer, inner_k):
    """Train XGBoost with nested inner CV to select best n_estimators."""
    import xgboost as xgb

    inner_kf = KFold(n_splits=inner_k, shuffle=True, random_state=RANDOM_SEED)
    best_cv_rmse = float('inf')
    best_n_est = N_ESTIMATORS_GRID[0]

    for n_est in N_ESTIMATORS_GRID:
        fold_rmses = []
        for train_idx, val_idx in inner_kf.split(X_train_outer):
            X_train_inner, X_val_inner = X_train_outer[train_idx], X_train_outer[val_idx]
            y_train_inner, y_val_inner = y_train_outer[train_idx], y_train_outer[val_idx]

            xgb_params = params.copy()
            xgb_params.update(XGBOOST_FIXED_PARAMS)
            xgb_params['n_estimators'] = n_est
            xgb_params['n_jobs'] = XGB_INNER_N_JOBS

            model = xgb.XGBRegressor(**xgb_params, random_state=RANDOM_SEED)
            model.fit(X_train_inner, y_train_inner, verbose=False)

            y_val_pred = model.predict(X_val_inner)
            fold_rmses.append(np.sqrt(np.mean((y_val_inner - y_val_pred) ** 2)))

        mean_cv_rmse = float(np.mean(fold_rmses))
        if mean_cv_rmse < best_cv_rmse:
            best_cv_rmse = mean_cv_rmse
            best_n_est = n_est

    xgb_params = params.copy()
    xgb_params.update(XGBOOST_FIXED_PARAMS)
    xgb_params['n_estimators'] = best_n_est
    xgb_params['n_jobs'] = XGB_INNER_N_JOBS

    model = xgb.XGBRegressor(**xgb_params, random_state=RANDOM_SEED)
    model.fit(X_train_outer, y_train_outer, verbose=False)

    return model, best_n_est, best_cv_rmse


def train_and_evaluate_metagb(params, pred_frac, X_train_outer, y_train_outer, inner_k):
    """Train MetaGB with nested inner CV to select best n_estimators."""
    from metagb_utils import MetaGB

    inner_kf = KFold(n_splits=inner_k, shuffle=True, random_state=RANDOM_SEED)
    best_cv_rmse = float('inf')
    best_n_est = N_ESTIMATORS_GRID[0]

    for n_est in N_ESTIMATORS_GRID:
        fold_rmses = []
        for train_idx, val_idx in inner_kf.split(X_train_outer):
            X_train_inner, X_val_inner = X_train_outer[train_idx], X_train_outer[val_idx]
            y_train_inner, y_val_inner = y_train_outer[train_idx], y_train_outer[val_idx]

            metagb_params = {
                'learning_rate': params['learning_rate'],
                'num_trees': n_est,
                'feature_fraction': params['colsample_bytree'],
                'bagging_fraction': params['subsample'],
                'max_depth': params['max_depth'],
                'pred_feature_fraction': pred_frac,
                'seed': RANDOM_SEED
            }
            metagb_params.update(METAGB_FIXED_PARAMS)

            model = MetaGB(**metagb_params)
            model.fit(X_train_inner, y_train_inner)

            y_val_pred = model.predict(X_val_inner)
            fold_rmses.append(np.sqrt(np.mean((y_val_inner - y_val_pred) ** 2)))

        mean_cv_rmse = float(np.mean(fold_rmses))
        if mean_cv_rmse < best_cv_rmse:
            best_cv_rmse = mean_cv_rmse
            best_n_est = n_est

    metagb_params = {
        'learning_rate': params['learning_rate'],
        'num_trees': best_n_est,
        'feature_fraction': params['colsample_bytree'],
        'bagging_fraction': params['subsample'],
        'max_depth': params['max_depth'],
        'pred_feature_fraction': pred_frac,
        'seed': RANDOM_SEED
    }
    metagb_params.update(METAGB_FIXED_PARAMS)

    model = MetaGB(**metagb_params)
    model.fit(X_train_outer, y_train_outer)

    return model, best_n_est, best_cv_rmse


def _evaluate_single_xgb_config(param_vals, param_names, X_train_outer, y_train_outer, X_test_outer, y_test_outer,
                                inner_k, outer_fold, outer_k):
    """Evaluate one hyperparameter configuration for XGBoost only."""
    params = dict(zip(param_names, param_vals))

    xgb_model, xgb_n_est, xgb_cv_rmse = train_and_evaluate_xgboost(
        params, X_train_outer, y_train_outer, inner_k
    )
    y_test_pred = xgb_model.predict(X_test_outer)
    xgb_metrics = calculate_metrics(y_test_outer, y_test_pred)

    return {
        'outer_fold': outer_fold,
        'outer_k': outer_k,
        'inner_k': inner_k,
        'model_type': 'XGBoost',
        'pred_feature_fraction': None,
        'params': params.copy(),
        'best_n_estimators': xgb_n_est,
        'cv_rmse': xgb_cv_rmse,
        'test_rmse': xgb_metrics['rmse'],
        'test_mae': xgb_metrics['mae'],
        'test_r2': xgb_metrics['r2']
    }


def _evaluate_single_metagb_config(param_vals, param_names, X_train_outer, y_train_outer, X_test_outer, y_test_outer,
                                   inner_k, outer_fold, outer_k):
    """Evaluate one hyperparameter configuration for all MetaGB pred_feature_fraction values."""
    params = dict(zip(param_names, param_vals))
    results = []

    for pred_frac in PRED_FRACTIONS:
        mgb_model, mgb_n_est, mgb_cv_rmse = train_and_evaluate_metagb(
            params, pred_frac, X_train_outer, y_train_outer, inner_k
        )
        y_test_pred = mgb_model.predict(X_test_outer)
        mgb_metrics = calculate_metrics(y_test_outer, y_test_pred)

        results.append({
            'outer_fold': outer_fold,
            'outer_k': outer_k,
            'inner_k': inner_k,
            'model_type': 'MetaGB',
            'pred_feature_fraction': pred_frac,
            'params': params.copy(),
            'best_n_estimators': mgb_n_est,
            'cv_rmse': mgb_cv_rmse,
            'test_rmse': mgb_metrics['rmse'],
            'test_mae': mgb_metrics['mae'],
            'test_r2': mgb_metrics['r2']
        })

    return results


def run_pred_fraction_study(dataset_name, csv_path, logger, results_dir, outer_k=5, inner_k=4):
    """Run pred_feature_fraction study with nested CV for a single dataset."""
    logger.info(f"\n{'='*80}")
    logger.info(f"Dataset: {dataset_name}")
    logger.info(f"{'='*80}")

    X, y = load_dataset(csv_path)
    logger.info(f"Total samples: {len(X)}, Features: {X.shape[1]}")

    param_names = list(FIXED_PARAM_GRID.keys())
    param_values = list(FIXED_PARAM_GRID.values())
    param_combinations = list(product(*param_values))

    logger.info(f"Testing {len(param_combinations)} hyperparameter combinations")
    logger.info(f"Outer CV: {outer_k} folds | Inner CV: {inner_k} folds")
    logger.info(f"Each outer fold runs XGBoost phase first, then MetaGB phase")

    flat_results = []
    outer_kf = KFold(n_splits=outer_k, shuffle=True, random_state=RANDOM_SEED)

    for outer_fold, (train_idx, test_idx) in enumerate(outer_kf.split(X), start=1):
        X_train_outer, X_test_outer = X[train_idx], X[test_idx]
        y_train_outer, y_test_outer = y[train_idx], y[test_idx]

        logger.info(
            f"\n[Outer Fold {outer_fold}/{outer_k}] "
            f"Train: {len(X_train_outer)}, Test: {len(X_test_outer)}"
        )

        logger.info(f"  [Phase-1] XGBoost search (parameter-level parallel n_jobs={N_JOBS}, model n_jobs={XGB_INNER_N_JOBS})")
        xgb_results = Parallel(n_jobs=N_JOBS, verbose=10)(
            delayed(_evaluate_single_xgb_config)(
                param_vals, param_names,
                X_train_outer, y_train_outer, X_test_outer, y_test_outer,
                inner_k, outer_fold, outer_k
            )
            for param_vals in param_combinations
        )
        flat_results.extend(xgb_results)

        logger.info(f"  [Phase-2] MetaGB search (parameter-level parallel n_jobs={N_JOBS})")
        metagb_results = Parallel(n_jobs=N_JOBS, verbose=10)(
            delayed(_evaluate_single_metagb_config)(
                param_vals, param_names,
                X_train_outer, y_train_outer, X_test_outer, y_test_outer,
                inner_k, outer_fold, outer_k
            )
            for param_vals in param_combinations
        )

        for config_results in metagb_results:
            flat_results.extend(config_results)

        fold_suffix = build_outer_fold_suffix(outer_fold)
        pd.DataFrame(flat_results).to_csv(
            os.path.join(results_dir, f'{dataset_name}_pred_fraction_study{fold_suffix}.csv'),
            index=False
        )

    df = pd.DataFrame(flat_results)
    outer_suffix = build_outer_fold_suffix(outer_k)
    csv_path = os.path.join(results_dir, f'{dataset_name}_pred_fraction_study{outer_suffix}.csv')
    df.to_csv(csv_path, index=False)

    logger.info(f"\nResults saved to: {csv_path}")
    logger.info(f"Total experiments: {len(flat_results)}")

    logger.info(f"\n{'='*80}")
    logger.info("Summary Statistics")
    logger.info(f"{'='*80}")

    xgb_results = df[df['model_type'] == 'XGBoost']
    logger.info(
        f"\nXGBoost: Mean Test RMSE = {xgb_results['test_rmse'].mean():.4f} "
        f"± {xgb_results['test_rmse'].std():.4f}"
    )

    for pred_frac in PRED_FRACTIONS:
        mgb_results = df[(df['model_type'] == 'MetaGB') & (df['pred_feature_fraction'] == pred_frac)]
        logger.info(
            f"MetaGB (pred={pred_frac:.1f}): Mean Test RMSE = {mgb_results['test_rmse'].mean():.4f} "
            f"± {mgb_results['test_rmse'].std():.4f}"
        )

    return df

def save_outer_cv_aggregate(df, dataset_name, results_dir, outer_k):
    """Save per-dataset outer-fold aggregated mean/std results."""
    if df.empty:
        return

    df = df.copy()
    df['params_json'] = df['params'].apply(lambda value: json.dumps(value, sort_keys=True))
    group_cols = ['model_type', 'pred_feature_fraction', 'params_json', 'outer_k', 'inner_k']
    metric_cols = ['best_n_estimators', 'cv_rmse', 'test_rmse', 'test_mae', 'test_r2']

    agg_df = df.groupby(group_cols, dropna=False, as_index=False)[metric_cols].agg(['mean', 'std'])
    agg_df.columns = [
        '_'.join(col).strip('_') if isinstance(col, tuple) else col
        for col in agg_df.columns.to_flat_index()
    ]
    agg_df.insert(0, 'dataset', dataset_name)

    outer_suffix = build_outer_fold_suffix(outer_k)
    csv_path = os.path.join(results_dir, f'{dataset_name}_pred_fraction_study_outercv_aggregate{outer_suffix}.csv')
    json_path = os.path.join(results_dir, f'{dataset_name}_pred_fraction_study_outercv_aggregate{outer_suffix}.json')
    agg_df.to_csv(csv_path, index=False)
    with open(json_path, 'w') as f:
        json.dump(agg_df.to_dict(orient='records'), f, indent=2)

def main(dataset_filter=None, outer_k=5, inner_k=4):
    """Main function to run pred_feature_fraction study."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    results_dir = os.path.join(base_dir, 'results', 'pred_fraction_study')
    logs_dir = os.path.join(base_dir, 'logs', 'pred_fraction_study')

    os.makedirs(results_dir, exist_ok=True)
    os.makedirs(logs_dir, exist_ok=True)

    logger = ExperimentLogger('pred_fraction_study', log_dir=logs_dir)

    logger.info("="*80)
    logger.info("Experiment: pred_feature_fraction Impact Study")
    logger.info("="*80)
    logger.info(f"Outer CV: {outer_k} folds")
    logger.info(f"Inner CV: {inner_k} folds")
    logger.info(f"Fixed params (except n_estimators): {FIXED_PARAM_GRID}")
    logger.info(f"n_estimators search space: {N_ESTIMATORS_GRID}")
    logger.info(f"pred_feature_fraction values: {PRED_FRACTIONS}")

    data_dir = os.path.join(base_dir, '..', 'dataset', 'tabArena_regression')
    datasets = dataset_filter if dataset_filter else EXP1_DATASETS

    dataset_tasks = []
    for ds in datasets:
        name = os.path.splitext(ds)[0]
        path = os.path.join(data_dir, ds)

        if not os.path.exists(path):
            logger.warning(f"Dataset not found: {path}")
            continue

        dataset_tasks.append({
            'exp_tag': 'pred_fraction_study',
            'dataset_name': name,
            'dataset_path': path,
            'results_dir': results_dir,
            'logs_dir': logs_dir,
            'outer_k': outer_k,
            'inner_k': inner_k,
        })

    if not dataset_tasks:
        logger.warning("No valid dataset tasks found.")
        logger.close()
        return

    max_workers = min(TOTAL_DATASET_WORKERS, len(dataset_tasks))
    logger.info(f"Dataset-level parallel enabled: workers={max_workers}, model-level N_JOBS={N_JOBS}")

    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        future_map = {executor.submit(_run_pred_fraction_task, task): task['dataset_name'] for task in dataset_tasks}
        for idx, future in enumerate(as_completed(future_map), start=1):
            dataset_name = future_map[future]
            result = future.result()
            if result['error']:
                logger.error(f"[{idx}/{len(dataset_tasks)}] Failed on {dataset_name}")
                logger.error(result['error'])
            else:
                logger.info(f"[{idx}/{len(dataset_tasks)}] Completed {dataset_name} ({result['rows']} rows)")

    logger.info("\nExperiment completed!")
    logger.close()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='Study pred_feature_fraction impact')
    parser.add_argument('--outer_k', type=int, default=5, help='Outer CV folds')
    parser.add_argument('--inner_k', type=int, default=4, help='Inner CV folds')
    parser.add_argument('--dataset', type=str, nargs='*', help='Specific datasets')

    args = parser.parse_args()

    main(dataset_filter=args.dataset, outer_k=args.outer_k, inner_k=args.inner_k)

"""
Debug version: runs single task sequentially, prints full traceback.
Usage: python exp1_fixed_debug.py --dataset QSAR_fish_toxicity --fold 3 --branch C
"""
import sys, os, json, traceback, warnings
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from joblib import Parallel, delayed

warnings.filterwarnings('ignore')

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
EXP1_DIR = os.path.join(ROOT_DIR, 'exp1_ordinal')
DATA_DIR = os.path.join(ROOT_DIR, 'dataset', 'tabArena_regression')

sys.path.insert(0, EXP1_DIR)
sys.path.insert(0, os.path.join(EXP1_DIR, 'utils'))
sys.path.insert(0, os.path.join(EXP1_DIR, 'metagb'))

RANDOM_SEED = 42
OUTER_K     = 5
INNER_K     = 4
PRED_VALUES = [round(i * 0.1, 1) for i in range(11)]

def load_data(csv_path):
    df = pd.read_csv(csv_path)
    for col in df.select_dtypes(exclude=[np.number]).columns:
        df[col], _ = pd.factorize(df[col], sort=True)
    df = df.dropna()
    return df.iloc[:, :-1].values, df.iloc[:, -1].values

def load_best_params(dataset_name, model, outer_fold):
    fname = f"exp1_bestparams_{model}_out{outer_fold}.json"
    path  = os.path.join(EXP1_DIR, 'logs', 'exp1_bestparams', dataset_name, fname)
    with open(path) as f:
        return json.load(f)['best_params']

def map_xgb_to_metagb(p):
    mapping   = {'n_estimators':'num_trees','colsample_bytree':'feature_fraction','subsample':'bagging_fraction'}
    drop_keys = {'reg_lambda','enable_categorical','min_child_weight','tree_method','device','n_jobs'}
    result = {}
    for k, v in p.items():
        if k in drop_keys: continue
        if k == 'min_child_weight':
            result['min_data_in_leaf'] = max(1, int(round(v)))
        elif k in mapping:
            result[mapping[k]] = v
        else:
            result[k] = v
    result.setdefault('version', 3)
    result.setdefault('min_data_in_leaf', 10)
    result.setdefault('max_bin', 255)
    result.setdefault('bagging_fraction', 0.8)
    result.setdefault('feature_fraction', 0.8)
    return result

def train_metagb(params, X_train, y_train):
    from metagb.metagb_utils import MetaGB
    p = params.copy()
    p['seed'] = RANDOM_SEED
    print(f"    [MetaGB params] {p}")
    model = MetaGB(**p)
    model.fit(X_train, y_train)
    return model

def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))

def _eval_pred_inner(pred_val, base_params, X_train_outer, y_train_outer):
    params = base_params.copy()
    params['pred_feature_fraction'] = pred_val
    inner_kf = KFold(n_splits=INNER_K, shuffle=True, random_state=RANDOM_SEED)
    fold_rmses = []
    for tr_idx, val_idx in inner_kf.split(X_train_outer):
        model = train_metagb(params, X_train_outer[tr_idx], y_train_outer[tr_idx])
        fold_rmses.append(rmse(y_train_outer[val_idx], model.predict(X_train_outer[val_idx])))
    return {'pred': pred_val, 'cv_rmse': float(np.mean(fold_rmses))}

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', default='QSAR_fish_toxicity')
    parser.add_argument('--fold',    type=int, default=3)
    parser.add_argument('--branch',  default='C', choices=['A','B','C'])
    parser.add_argument('--n_jobs',  type=int, default=1)
    args = parser.parse_args()

    csv_path = os.path.join(DATA_DIR, args.dataset + '.csv')
    X, y = load_data(csv_path)
    print(f"Data shape: {X.shape}")

    outer_kf = KFold(n_splits=OUTER_K, shuffle=True, random_state=RANDOM_SEED)
    splits = list(outer_kf.split(X))
    tr_idx, te_idx = splits[args.fold - 1]
    X_train, X_test = X[tr_idx], X[te_idx]
    y_train, y_test = y[tr_idx], y[te_idx]
    print(f"Train: {len(X_train)}, Test: {len(X_test)}")

    xgb_params = load_best_params(args.dataset, 'xgboost', args.fold)
    print(f"XGB best params: {xgb_params}")

    if args.branch == 'B':
        mgb_params = load_best_params(args.dataset, 'metagb', args.fold)
        print(f"MGB best params: {mgb_params}")
        base = {k: v for k, v in mgb_params.items() if k != 'pred_feature_fraction'}
        for old, new in [('n_estimators','num_trees'),('colsample_bytree','feature_fraction'),
                         ('colsample','feature_fraction'),('subsample','bagging_fraction')]:
            if old in base: base[new] = base.pop(old)
        if 'min_child_weight' in base:
            base['min_data_in_leaf'] = max(1, int(round(base.pop('min_child_weight'))))
        base.setdefault('version', 3)
    else:  # C
        base = map_xgb_to_metagb(xgb_params)

    print(f"Base MetaGB params (no pred): {base}")

    # Test just pred=0.0 first
    print("\n--- Testing pred=0.0 only (sequential) ---")
    try:
        result = _eval_pred_inner(0.0, base, X_train, y_train)
        print(f"pred=0.0 cv_rmse={result['cv_rmse']:.4f}")
    except Exception:
        print("FULL TRACEBACK:")
        traceback.print_exc()
        return

    # Test all preds sequentially
    print("\n--- Testing all 11 pred values sequentially ---")
    for pv in PRED_VALUES:
        try:
            r = _eval_pred_inner(pv, base, X_train, y_train)
            print(f"  pred={pv:.1f}  cv_rmse={r['cv_rmse']:.4f}")
        except Exception:
            print(f"  pred={pv:.1f}  FAILED:")
            traceback.print_exc()

if __name__ == '__main__':
    main()
